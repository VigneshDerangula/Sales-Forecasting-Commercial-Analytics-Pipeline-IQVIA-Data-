-- ============================================================
-- pharma_analysis.sql
-- Commercial Analytics SQL — Brand, Territory, HCP, Forecast
-- All queries run against pharma.db (SQLite)
-- ============================================================


-- ─────────────────────────────────────────────────────────────
-- 1. BRAND-LEVEL ANNUAL PERFORMANCE
-- ─────────────────────────────────────────────────────────────
-- KPI: Total units, revenue, avg market share by brand & year
SELECT
    brand,
    therapy_area,
    year,
    SUM(units_sold)                          AS total_units,
    ROUND(SUM(revenue_usd), 2)               AS total_revenue,
    ROUND(AVG(market_share_pct), 2)          AS avg_market_share,
    ROUND(SUM(revenue_usd) / SUM(units_sold), 2) AS avg_price_per_unit
FROM sales
GROUP BY brand, therapy_area, year
ORDER BY year, total_revenue DESC;


-- ─────────────────────────────────────────────────────────────
-- 2. QUARTERLY REVENUE TREND (all brands)
-- ─────────────────────────────────────────────────────────────
SELECT
    year,
    quarter,
    brand,
    SUM(units_sold)             AS units,
    ROUND(SUM(revenue_usd), 2)  AS revenue
FROM sales
GROUP BY year, quarter, brand
ORDER BY year, quarter, brand;


-- ─────────────────────────────────────────────────────────────
-- 3. REGIONAL PERFORMANCE BREAKDOWN
-- ─────────────────────────────────────────────────────────────
SELECT
    region,
    brand,
    year,
    SUM(units_sold)                          AS total_units,
    ROUND(SUM(revenue_usd), 2)               AS total_revenue,
    ROUND(AVG(market_share_pct), 2)          AS avg_market_share
FROM sales
GROUP BY region, brand, year
ORDER BY year, region, total_revenue DESC;


-- ─────────────────────────────────────────────────────────────
-- 4. TERRITORY ALIGNMENT — TOP 10 TERRITORIES BY REVENUE
-- ─────────────────────────────────────────────────────────────
SELECT
    territory,
    rep_id,
    region,
    SUM(units_sold)            AS total_units,
    ROUND(SUM(revenue_usd), 2) AS total_revenue,
    COUNT(DISTINCT brand)      AS brands_covered
FROM sales
GROUP BY territory, rep_id, region
ORDER BY total_revenue DESC
LIMIT 10;


-- ─────────────────────────────────────────────────────────────
-- 5. HCP ENGAGEMENT VS SALES CORRELATION (territory-month)
-- ─────────────────────────────────────────────────────────────
SELECT
    s.date,
    s.territory,
    s.brand,
    SUM(s.units_sold)              AS units_sold,
    ROUND(SUM(s.revenue_usd), 2)   AS revenue,
    h.hcp_calls,
    h.hcp_visits,
    h.samples_distributed,
    h.digital_interactions
FROM sales s
JOIN hcp_engagement h
    ON s.date = h.date
   AND s.territory = h.territory
   AND s.brand = h.brand
GROUP BY s.date, s.territory, s.brand
ORDER BY s.date, s.territory;


-- ─────────────────────────────────────────────────────────────
-- 6. MARKET SHARE TREND — MONTHLY MOVING AVERAGE (3-month)
-- ─────────────────────────────────────────────────────────────
SELECT
    brand,
    date,
    ROUND(AVG(market_share_pct), 2) AS monthly_avg_share,
    ROUND(
        AVG(AVG(market_share_pct)) OVER (
            PARTITION BY brand
            ORDER BY date
            ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 2
    ) AS rolling_3m_share
FROM sales
GROUP BY brand, date
ORDER BY brand, date;


-- ─────────────────────────────────────────────────────────────
-- 7. YoY REVENUE GROWTH BY BRAND
-- ─────────────────────────────────────────────────────────────
WITH yearly AS (
    SELECT
        brand,
        year,
        ROUND(SUM(revenue_usd), 2) AS revenue
    FROM sales
    GROUP BY brand, year
)
SELECT
    a.brand,
    a.year                                         AS current_year,
    a.revenue                                      AS current_revenue,
    b.revenue                                      AS prior_revenue,
    ROUND(100.0 * (a.revenue - b.revenue) / b.revenue, 2) AS yoy_growth_pct
FROM yearly a
LEFT JOIN yearly b
    ON a.brand = b.brand AND a.year = b.year + 1
ORDER BY a.brand, a.year;


-- ─────────────────────────────────────────────────────────────
-- 8. MARKET MIX — SPEND VS REVENUE IMPACT
-- ─────────────────────────────────────────────────────────────
SELECT
    m.brand,
    m.date,
    ROUND(m.tv_spend_usd + m.digital_spend_usd + m.print_spend_usd, 2) AS total_spend,
    ROUND(SUM(s.revenue_usd), 2)  AS brand_revenue,
    ROUND(
        SUM(s.revenue_usd) /
        NULLIF(m.tv_spend_usd + m.digital_spend_usd + m.print_spend_usd, 0)
    , 2)  AS revenue_per_spend_dollar
FROM market_mix m
JOIN sales s
    ON m.date = s.date AND m.brand = s.brand
GROUP BY m.brand, m.date
ORDER BY m.brand, m.date;


-- ─────────────────────────────────────────────────────────────
-- 9. REP-LEVEL PRODUCTIVITY (units per HCP visit)
-- ─────────────────────────────────────────────────────────────
SELECT
    s.rep_id,
    s.region,
    SUM(s.units_sold)                                       AS total_units,
    SUM(h.hcp_visits)                                       AS total_visits,
    ROUND(1.0 * SUM(s.units_sold) / NULLIF(SUM(h.hcp_visits), 0), 1) AS units_per_visit
FROM sales s
JOIN hcp_engagement h
    ON s.date = h.date
   AND s.territory = h.territory
   AND s.brand = h.brand
GROUP BY s.rep_id, s.region
ORDER BY units_per_visit DESC;


-- ─────────────────────────────────────────────────────────────
-- 10. DEMAND VISIBILITY — LAST QUARTER ACTUALS SUMMARY
-- ─────────────────────────────────────────────────────────────
SELECT
    brand,
    quarter,
    year,
    SUM(units_sold)             AS total_units,
    ROUND(SUM(revenue_usd), 2)  AS total_revenue,
    ROUND(AVG(market_share_pct), 2) AS avg_share
FROM sales
WHERE year = 2023 AND quarter = 'Q4'
GROUP BY brand, quarter, year
ORDER BY total_revenue DESC;
